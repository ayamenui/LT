/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "leaveserver",
  description: "サーバーを退出します。",
  category: "OWNER",
  botPermissions: ["EmbedLinks"],
  command: {
    enabled: true,
    minArgsCount: 1,
    usage: "<serverId>",
  },
  slashCommand: {
    enabled: false,
  },

  async messageRun(message, args, data) {
    const input = args[0];
    const guild = message.client.guilds.cache.get(input);
    if (!guild) {
      return message.safeReply(
        `サーバーが見つかりません。正しいサーバーIDを提供してください。
        サーバーIDを見つけるには、${data.prefix}findserver または ${data.prefix}listservers を使用してください`
      );
    }

    const name = guild.name;
    try {
      await guild.leave();
      return message.safeReply(`サーバー \`${name}\` を正常に退出しました`);
    } catch (err) {
      message.client.logger.error("GuildLeave", err);
      return message.safeReply(`サーバー \`${name}\` からの退出に失敗しました`);
    }
  },
};
