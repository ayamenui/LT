const SnakeGame = require("snakecord");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "snake",
  description: "Discordでスネークゲームをプレイ",
  cooldown: 300,
  category: "FUN",
  botPermissions: ["SendMessages", "EmbedLinks", "AddReactions", "ReadMessageHistory", "ManageMessages"],
  command: {
    enabled: true,
  },
  slashCommand: {
    enabled: true,
  },

  async messageRun(message, args) {
    await message.safeReply("**スネークゲームを開始します**");
    await startSnakeGame(message);
  },

  async interactionRun(interaction) {
    await interaction.followUp("**スネークゲームを開始します**");
    await startSnakeGame(interaction);
  },
};

async function startSnakeGame(data) {
  const snakeGame = new SnakeGame({
    title: "スネークゲーム",
    color: "BLUE",
    timestamp: true,
    gameOverTitle: "ゲームオーバー",
  });

  await snakeGame.newGame(data);
}
