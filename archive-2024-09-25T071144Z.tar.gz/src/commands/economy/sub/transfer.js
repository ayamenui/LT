const { EmbedBuilder } = require("discord.js");
const { getUser } = require("@schemas/User");
const { ECONOMY, EMBED_COLORS } = require("@root/config");

module.exports = async (self, target, coins) => {
  if (isNaN(coins) || coins <= 0) return "有効なコインの金額を入力してください";
  if (target.bot) return "ボットにコインを送金することはできません！";
  if (target.id === self.id) return "自分にコインを送金することはできません！";

  const userDb = await getUser(self);

  if (userDb.bank < coins) {
    return `銀行残高が不足しています！ あなたの銀行口座には ${userDb.bank}${ECONOMY.CURRENCY} しかありません。${
      userDb.coins > 0 && "\n送金する前にコインを銀行に預ける必要があります"
    } `;
  }

  const targetDb = await getUser(target);

  userDb.bank -= coins;
  targetDb.bank += coins;

  await userDb.save();
  await targetDb.save();

  const embed = new EmbedBuilder()
    .setColor(EMBED_COLORS.BOT_EMBED)
    .setAuthor({ name: "残高更新" })
    .setDescription(`${coins}${ECONOMY.CURRENCY} を ${target.username} に正常に送金しました`)
    .setTimestamp(Date.now());

  return { embeds: [embed] };
};
