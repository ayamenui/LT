const { ApplicationCommandOptionType } = require("discord.js");
const balance = require("./sub/balance");
const deposit = require("./sub/deposit");
const transfer = require("./sub/transfer");
const withdraw = require("./sub/withdraw");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "bank",
  description: "銀行の操作にアクセスする",
  category: "ECONOMY",
  botPermissions: ["EmbedLinks"],
  command: {
    enabled: true,
    minArgsCount: 1,
    subcommands: [
      {
        trigger: "balance",
        description: "自分の残高を確認する",
      },
      {
        trigger: "deposit <coins>",
        description: "コインを銀行口座に預ける",
      },
      {
        trigger: "withdraw <coins>",
        description: "銀行口座からコインを引き出す",
      },
      {
        trigger: "transfer <user> <coins>",
        description: "他のユーザーにコインを送金する",
      },
    ],
  },
  slashCommand: {
    enabled: true,
    options: [
      {
        name: "balance",
        description: "コインの残高を確認する",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "user",
            description: "ユーザーの名前",
            type: ApplicationCommandOptionType.User,
            required: false,
          },
        ],
      },
      {
        name: "deposit",
        description: "コインを銀行口座に預ける",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "coins",
            description: "預けるコインの数",
            type: ApplicationCommandOptionType.Integer,
            required: true,
          },
        ],
      },
      {
        name: "withdraw",
        description: "銀行口座からコインを引き出す",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "coins",
            description: "引き出すコインの数",
            type: ApplicationCommandOptionType.Integer,
            required: true,
          },
        ],
      },
      {
        name: "transfer",
        description: "他のユーザーにコインを送金する",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "user",
            description: "コインを送金するユーザー",
            type: ApplicationCommandOptionType.User,
            required: true,
          },
          {
            name: "coins",
            description: "送金するコインの数",
            type: ApplicationCommandOptionType.Integer,
            required: true,
          },
        ],
      },
    ],
  },

  async messageRun(message, args) {
    const sub = args[0];
    let response;

    if (sub === "balance") {
      const resolved = (await message.guild.resolveMember(args[1])) || message.member;
      response = await balance(resolved.user);
    }

    //
    else if (sub === "deposit") {
      const coins = args.length && parseInt(args[1]);
      if (isNaN(coins)) return message.safeReply("預けるコインの有効な数を指定してください");
      response = await deposit(message.author, coins);
    }

    //
    else if (sub === "withdraw") {
      const coins = args.length && parseInt(args[1]);
      if (isNaN(coins)) return message.safeReply("引き出すコインの有効な数を指定してください");
      response = await withdraw(message.author, coins);
    }

    //
    else if (sub === "transfer") {
      if (args.length < 3) return message.safeReply("送金するユーザーとコインの数を指定してください");
      const target = await message.guild.resolveMember(args[1], true);
      if (!target) return message.safeReply("コインを送金する有効なユーザーを指定してください");
      const coins = parseInt(args[2]);
      if (isNaN(coins)) return message.safeReply("送金するコインの有効な数を指定してください");
      response = await transfer(message.author, target.user, coins);
    }

    //
    else {
      return message.safeReply("無効なコマンドの使用法です");
    }

    await message.safeReply(response);
  },

  async interactionRun(interaction) {
    const sub = interaction.options.getSubcommand();
    let response;

    // balance
    if (sub === "balance") {
      const user = interaction.options.getUser("user") || interaction.user;
      response = await balance(user);
    }

    // deposit
    else if (sub === "deposit") {
      const coins = interaction.options.getInteger("coins");
      response = await deposit(interaction.user, coins);
    }

    // withdraw
    else if (sub === "withdraw") {
      const coins = interaction.options.getInteger("coins");
      response = await withdraw(interaction.user, coins);
    }

    // transfer
    else if (sub === "transfer") {
      const user = interaction.options.getUser("user");
      const coins = interaction.options.getInteger("coins");
      response = await transfer(interaction.user, user, coins);
    }

    await interaction.followUp(response);
  },
};
