const { ApplicationCommandOptionType } = require("discord.js");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "inviterank",
  description: "招待ランクの設定を行います",
  category: "INVITE",
  userPermissions: ["ManageGuild"],
  command: {
    enabled: true,
    usage: "<役職名> <招待数>",
    minArgsCount: 2,
    subcommands: [
      {
        trigger: "add <role> <invites>",
        description: "特定の招待数に達した後に自動的に役職を付与します",
      },
      {
        trigger: "remove role",
        description: "設定された招待ランクの役職を削除します",
      },
    ],
  },
  slashCommand: {
    enabled: true,
    ephemeral: true,
    options: [
      {
        name: "add",
        description: "新しい招待ランクを追加します",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "role",
            description: "付与する役職",
            type: ApplicationCommandOptionType.Role,
            required: true,
          },
          {
            name: "invites",
            description: "その役職を取得するために必要な招待数",
            type: ApplicationCommandOptionType.Integer,
            required: true,
          },
        ],
      },
      {
        name: "remove",
        description: "以前に設定された招待ランクを削除します",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "role",
            description: "設定された招待ランクの役職",
            type: ApplicationCommandOptionType.Role,
            required: true,
          },
        ],
      },
    ],
  },

  async messageRun(message, args, data) {
    const sub = args[0].toLowerCase();

    if (sub === "add") {
      const query = args[1];
      const invites = args[2];

      if (isNaN(invites)) return message.safeReply(`\`${invites}\` は無効な招待数です`);
      const role = message.guild.findMatchingRoles(query)[0];
      if (!role) return message.safeReply(`\`${query}\` に一致する役職が見つかりません`);

      const response = await addInviteRank(message, role, invites, data.settings);
      await message.safeReply(response);
    }

    //
    else if (sub === "remove") {
      const query = args[1];
      const role = message.guild.findMatchingRoles(query)[0];
      if (!role) return message.safeReply(`\`${query}\` に一致する役職が見つかりません`);
      const response = await removeInviteRank(message, role, data.settings);
      await message.safeReply(response);
    }

    //
    else {
      await message.safeReply("コマンドの使用方法が間違っています！");
    }
  },

  async interactionRun(interaction, data) {
    const sub = interaction.options.getSubcommand();

    //
    if (sub === "add") {
      const role = interaction.options.getRole("role");
      const invites = interaction.options.getInteger("invites");

      const response = await addInviteRank(interaction, role, invites, data.settings);
      await interaction.followUp(response);
    }

    //
    else if (sub === "remove") {
      const role = interaction.options.getRole("role");
      const response = await removeInviteRank(interaction, role, data.settings);
      await interaction.followUp(response);
    }
  },
};

async function addInviteRank({ guild }, role, invites, settings) {
  if (!settings.invite.tracking) return `このサーバーでは招待の追跡が無効です`;

  if (role.managed) {
    return "ボットの役職には設定できません";
  }

  if (guild.roles.everyone.id === role.id) {
    return "everyone 役職には設定できません。";
  }

  if (!role.editable) {
    return "その役職にメンバーを移動する権限がありません。その役職は私の最上位の役職の下にありますか？";
  }

  const exists = settings.invite.ranks.find((obj) => obj._id === role.id);

  let msg = "";
  if (exists) {
    exists.invites = invites;
    msg += "この役職に対して以前の設定が見つかりました。データを上書きします\n";
  } else {
    settings.invite.ranks.push({ _id: role.id, invites });
  }

  await settings.save();
  return `${msg}成功しました！設定が保存されました。`;
}

async function removeInviteRank({ guild }, role, settings) {
  if (!settings.invite.tracking) return `このサーバーでは招待の追跡が無効です`;

  if (role.managed) {
    return "ボットの役職には設定できません";
  }

  if (guild.roles.everyone.id === role.id) {
    return "everyone 役職には設定できません。";
  }

  if (!role.editable) {
    return "その役職からメンバーを移動する権限がありません。その役職は私の最上位の役職の下にありますか？";
  }

  const exists = settings.invite.ranks.find((obj) => obj._id === role.id);
  if (!exists) return "その役職には以前に設定された招待ランクが見つかりません";

  // 配列から要素を削除する
  const i = settings.invite.ranks.findIndex((obj) => obj._id === role.id);
  if (i > -1) settings.invite.ranks.splice(i, 1);

  await settings.save();
  return "成功しました！設定が保存されました。";
}
