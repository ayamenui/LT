const { EmbedBuilder, ApplicationCommandOptionType } = require("discord.js");
const { MESSAGES } = require("@root/config.js");
const { getJson } = require("@helpers/HttpUtils");
const { stripIndent } = require("common-tags");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "github",
  description: "ユーザーのGitHub統計情報を表示します",
  cooldown: 10,
  category: "UTILITY",
  botPermissions: ["EmbedLinks"],
  command: {
    enabled: true,
    aliases: ["git"],
    usage: "<username>",
    minArgsCount: 1,
  },
  slashCommand: {
    enabled: true,
    options: [
      {
        name: "username",
        description: "GitHubのユーザー名",
        type: ApplicationCommandOptionType.String,
        required: true,
      },
    ],
  },

  async messageRun(message, args) {
    const username = args.join(" ");
    const response = await getGithubUser(username, message.author);
    await message.safeReply(response);
  },

  async interactionRun(interaction) {
    const username = interaction.options.getString("username");
    const response = await getGithubUser(username, interaction.user);
    await interaction.followUp(response);
  },
};

const websiteProvided = (text) => (text.startsWith("http://") ? true : text.startsWith("https://"));

async function getGithubUser(target, author) {
  const response = await getJson(`https://api.github.com/users/${target}`);
  if (response.status === 404) return "```指定された名前のユーザーは見つかりません```";
  if (!response.success) return MESSAGES.API_ERROR;

  const json = response.data;
  const {
    login: username,
    name,
    id: githubId,
    avatar_url: avatarUrl,
    html_url: userPageLink,
    followers,
    following,
    bio,
    location,
    blog,
  } = json;

  let website = websiteProvided(blog) ? `[クリックして開く](${blog})` : "提供されていません";
  if (website == null) website = "提供されていません";

  const embed = new EmbedBuilder()
    .setAuthor({
      name: `GitHubユーザー: ${username}`,
      url: userPageLink,
      iconURL: avatarUrl,
    })
    .addFields(
      {
        name: "ユーザー情報",
        value: stripIndent`
        **本名**: *${name || "提供されていません"}*
        **所在地**: *${location}*
        **GitHub ID**: *${githubId}*
        **ウェブサイト**: *${website}*\n`,
        inline: true,
      },
      {
        name: "ソーシャル統計",
        value: `**フォロワー数**: *${followers}*\n**フォロー中**: *${following}*`,
        inline: true,
      }
    )
    .setDescription(`**自己紹介**:\n${bio || "提供されていません"}`)
    .setImage(avatarUrl)
    .setColor(0x6e5494)
    .setFooter({ text: `リクエスト者: ${author.username}` });

  return { embeds: [embed] };
}
