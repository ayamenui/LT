const { EmbedBuilder, ApplicationCommandOptionType } = require("discord.js");
const { postToBin } = require("@helpers/HttpUtils");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "paste",
  description: "sourceb.inに内容を貼り付ける",
  cooldown: 5,
  category: "UTILITY",
  botPermissions: ["EmbedLinks"],
  command: {
    enabled: true,
    minArgsCount: 2,
    usage: "<タイトル> <内容>",
  },
  slashCommand: {
    enabled: true,
    options: [
      {
        name: "title",
        description: "コンテンツのタイトル",
        required: true,
        type: ApplicationCommandOptionType.String,
      },
      {
        name: "content",
        description: "貼り付ける内容",
        type: ApplicationCommandOptionType.String,
        required: true,
      },
    ],
  },

  async messageRun(message, args) {
    const title = args.shift();
    const content = args.join(" ");
    const response = await paste(content, title);
    await message.safeReply(response);
  },

  async interactionRun(interaction) {
    const title = interaction.options.getString("title");
    const content = interaction.options.getString("content");
    const response = await paste(content, title);
    await interaction.followUp(response);
  },
};

async function paste(content, title) {
  const response = await postToBin(content, title);
  if (!response) return "❌ 何か問題が発生しました";

  const embed = new EmbedBuilder()
    .setAuthor({ name: "Pasteリンク" })
    .setDescription(`🔸 通常: ${response.url}\n🔹 生: ${response.raw}`);

  return { embeds: [embed] };
}
