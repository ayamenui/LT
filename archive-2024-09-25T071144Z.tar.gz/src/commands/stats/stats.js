const { EmbedBuilder, ApplicationCommandOptionType } = require("discord.js");
const { getMemberStats } = require("@schemas/MemberStats");
const { EMBED_COLORS } = require("@root/config");
const { stripIndents } = require("common-tags");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "stats",
  description: "このサーバー内のメンバーの統計を表示します",
  cooldown: 5,
  category: "STATS",
  command: {
    enabled: true,
    usage: "[@member|id]",
  },
  slashCommand: {
    enabled: true,
    options: [
      {
        name: "user",
        description: "対象ユーザー",
        type: ApplicationCommandOptionType.User,
        required: false,
      },
    ],
  },

  async messageRun(message, args, data) {
    const target = (await message.guild.resolveMember(args[0])) || message.member;
    const response = await stats(target, data.settings);
    await message.safeReply(response);
  },

  async interactionRun(interaction, data) {
    const member = interaction.options.getMember("user") || interaction.member;
    const response = await stats(member, data.settings);
    await interaction.followUp(response);
  },
};

/**
 * @param {import('discord.js').GuildMember} member
 * @param {object} settings
 */
async function stats(member, settings) {
  if (!settings.stats.enabled) return "このサーバーでは統計追跡が無効になっています";
  const memberStats = await getMemberStats(member.guild.id, member.id);

  const embed = new EmbedBuilder()
    .setThumbnail(member.user.displayAvatarURL())
    .setColor(EMBED_COLORS.BOT_EMBED)
    .addFields(
      {
        name: "ユーザー名",
        value: member.user.username,
        inline: true,
      },
      {
        name: "ID",
        value: member.id,
        inline: true,
      },
      {
        name: "⌚ サーバー参加日",
        value: member.joinedAt.toLocaleString(),
        inline: false,
      },
      {
        name: "💬 メッセージ送信数",
        value: stripIndents`
      ❯ 送信メッセージ数: ${memberStats.messages}
      ❯ プレフィックスコマンド: ${memberStats.commands.prefix}
      ❯ スラッシュコマンド: ${memberStats.commands.slash}
      ❯ 獲得XP: ${memberStats.xp}
      ❯ 現在のレベル: ${memberStats.level}
    `,
        inline: false,
      },
      {
        name: "🎙️ ボイス統計",
        value: stripIndents`
      ❯ 総接続回数: ${memberStats.voice.connections}
      ❯ 使用時間: ${Math.floor(memberStats.voice.time / 60)} 分
    `,
      }
    )
    .setFooter({ text: "統計生成済み" })
    .setTimestamp();

  return { embeds: [embed] };
}
