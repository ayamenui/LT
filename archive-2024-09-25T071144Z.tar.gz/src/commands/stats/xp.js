const { ApplicationCommandOptionType, ChannelType } = require("discord.js");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "levelup",
  description: "レベルアップシステムを設定します",
  category: "STATS",
  userPermissions: ["ManageGuild"],
  command: {
    enabled: true,
    minArgsCount: 1,
    subcommands: [
      {
        trigger: "message <new-message>",
        description: "カスタムレベルアップメッセージを設定します",
      },
      {
        trigger: "channel <#channel|off>",
        description: "レベルアップメッセージを送信するチャンネルを設定します",
      },
    ],
  },
  slashCommand: {
    enabled: true,
    options: [
      {
        name: "message",
        description: "カスタムレベルアップメッセージを設定します",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "message",
            description: "ユーザーがレベルアップしたときに表示されるメッセージ",
            type: ApplicationCommandOptionType.String,
            required: true,
          },
        ],
      },
      {
        name: "channel",
        description: "レベルアップメッセージを送信するチャンネルを設定します",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "channel",
            description: "レベルアップメッセージを送信するチャンネル",
            type: ApplicationCommandOptionType.Channel,
            channelTypes: [ChannelType.GuildText],
            required: true,
          },
        ],
      },
    ],
  },

  async messageRun(message, args, data) {
    const sub = args[0];
    const subcommandArgs = args.slice(1);
    let response;

    // message
    if (sub === "message") {
      const msg = subcommandArgs.join(" ");
      response = await setMessage(msg, data.settings);
    }

    // channel
    else if (sub === "channel") {
      const input = subcommandArgs[0];
      let channel;

      if (input === "off") channel = "off";
      else {
        const match = message.guild.findMatchingChannels(input);
        if (match.length === 0) return message.safeReply("無効なチャンネルです。有効なチャンネルを指定してください");
        channel = match[0];
      }
      response = await setChannel(channel, data.settings);
    }

    // invalid
    else response = "無効なサブコマンドです";
    await message.safeReply(response);
  },

  async interactionRun(interaction, data) {
    const sub = interaction.options.getSubcommand();
    let response;

    if (sub === "message") response = await setMessage(interaction.options.getString("message"), data.settings);
    else if (sub === "channel") response = await setChannel(interaction.options.getChannel("channel"), data.settings);
    else response = "無効なサブコマンドです";

    await interaction.followUp(response);
  },
};

async function setMessage(message, settings) {
  if (!message) return "無効なメッセージです。メッセージを指定してください";
  settings.stats.xp.message = message;
  await settings.save();
  return `設定が保存されました。レベルアップメッセージが更新されました！`;
}

async function setChannel(channel, settings) {
  if (!channel) return "無効なチャンネルです。チャンネルを指定してください";

  if (channel === "off") settings.stats.xp.channel = null;
  else settings.stats.xp.channel = channel.id;

  await settings.save();
  return `設定が保存されました。レベルアップチャンネルが更新されました！`;
}
