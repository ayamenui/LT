const botinvite = require("../shared/botinvite");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "botinvite",
  description: "ボットの招待リンクを提供します",
  category: "INFORMATION",
  botPermissions: ["EmbedLinks"],
  command: {
    enabled: true,
  },

  async messageRun(message, args) {
    const response = botinvite(message.client);
    try {
      await message.author.send(response);
      return message.safeReply("DMで情報を確認してください！ :envelope_with_arrow:");
    } catch (ex) {
      return message.safeReply("情報を送信できませんでした！DMが開いていますか？");
    }
  },
};
