const { EmbedBuilder, escapeInlineCode, ApplicationCommandOptionType } = require("discord.js");
const { EMBED_COLORS } = require("@root/config");
const { getInvitesLb } = require("@schemas/Member");
const { getXpLb } = require("@schemas/MemberStats");
const { getReputationLb } = require("@schemas/User");

const leaderboardTypes = ["xp", "invite", "rep"];

/**
 * @type {import("@structures/Command")}
 */

module.exports = {
  name: "leaderboard",
  description: "XP、招待、Reputationのリーダーボードを表示",
  category: "情報",
  botPermissions: ["EmbedLinks"],
  command: {
    enabled: true,
    aliases: ["lb"],
    minArgsCount: 1,
    usage: "<xp|invite|rep>",
  },
  slashCommand: {
    enabled: true,
    options: [
      {
        name: "type",
        description: "表示するリーダーボードの種類",
        required: true,
        type: ApplicationCommandOptionType.String,
        choices: leaderboardTypes.map((type) => ({
          name: type,
          value: type,
        })),
      },
    ],
  },
  async messageRun(message, args, data) {
    const type = args[0].toLowerCase();
    let response;

    switch (type) {
      case "xp":
        response = await getXpLeaderboard(message, message.author, data.settings);
        break;
      case "invite":
        response = await getInviteLeaderboard(message, message.author, data.settings);
        break;
      case "rep":
        response = await getRepLeaderboard(message.author);
        break;
      default:
        response = "無効なリーダーボードの種類です。「xp」「invite」「rep」のいずれかを選択してください";
    }

    await message.safeReply(response);
  },

  async interactionRun(interaction, data) {
    const type = interaction.options.getString("type");
    let response;

    switch (type) {
      case "xp":
        response = await getXpLeaderboard(interaction, interaction.user, data.settings);
        break;
      case "invite":
        response = await getInviteLeaderboard(interaction, interaction.user, data.settings);
        break;
      case "rep":
        response = await getRepLeaderboard(interaction.user);
        break;
      default:
        response = "無効なリーダーボードの種類です。「xp」「invite」「rep」のいずれかを選択してください";
    }
    await interaction.followUp(response);
  },
};

// キャッシュエントリを保存するためのMapオブジェクトを作成
const cache = new Map();

async function getXpLeaderboard({ guild }, author, settings) {
  // ギルドIDとリーダーボードの種類を使用してキャッシュキーを作成
  const cacheKey = `${guild.id}:xp`;

  // このリクエストに対してキャッシュされた結果があるか確認
  if (cache.has(cacheKey)) {
    // キャッシュされた結果が存在する場合、それを返す
    return cache.get(cacheKey);
  }

  if (!settings.stats.enabled) return "このサーバーではリーダーボードが無効になっています";

  const lb = await getXpLb(guild.id, 10);
  if (lb.length === 0) return "リーダーボードにユーザーがいません";

  let collector = "";
  for (let i = 0; i < lb.length; i++) {
    try {
      const user = await author.client.users.fetch(lb[i].member_id);
      collector += `**#${(i + 1).toString()}** - ${escapeInlineCode(user.tag)}\n`;
    } catch (ex) {
      // 無視
    }
  }

  const embed = new EmbedBuilder()
    .setAuthor({ name: "XPリーダーボード" })
    .setColor(EMBED_COLORS.BOT_EMBED)
    .setDescription(collector)
    .setFooter({ text: `リクエスト者: ${author.tag}` });

  // キャッシュに結果を保存し、次回のリクエストに備える
  cache.set(cacheKey, { embeds: [embed] });
  return { embeds: [embed] };
}

async function getInviteLeaderboard({ guild }, author, settings) {
  // ギルドIDとリーダーボードの種類を使用してキャッシュキーを作成
  const cacheKey = `${guild.id}:invite`;

  // このリクエストに対してキャッシュされた結果があるか確認
  if (cache.has(cacheKey)) {
    // キャッシュされた結果が存在する場合、それを返す
    return cache.get(cacheKey);
  }

  if (!settings.invite.tracking) return "このサーバーでは招待追跡が無効になっています";

  const lb = await getInvitesLb(guild.id, 10);
  if (lb.length === 0) return "リーダーボードにユーザーがいません";

  let collector = "";
  for (let i = 0; i < lb.length; i++) {
    try {
      const memberId = lb[i].member_id;
      if (memberId === "VANITY") collector += `**#${(i + 1).toString()}** - Vanity URL [${lb[i].invites}]\n`;
      else {
        const user = await author.client.users.fetch(lb[i].member_id);
        collector += `**#${(i + 1).toString()}** - ${escapeInlineCode(user.tag)} [${lb[i].invites}]\n`;
      }
    } catch (ex) {
      collector += `**#${(i + 1).toString()}** - DeletedUser#0000 [${lb[i].invites}]\n`;
    }
  }

  const embed = new EmbedBuilder()
    .setAuthor({ name: "招待リーダーボード" })
    .setColor(EMBED_COLORS.BOT_EMBED)
    .setDescription(collector)
    .setFooter({ text: `リクエスト者: ${author.tag}` });

  // キャッシュに結果を保存し、次回のリクエストに備える
  cache.set(cacheKey, { embeds: [embed] });
  return { embeds: [embed] };
}

async function getRepLeaderboard(author) {
  // ユーザーIDとリーダーボードの種類を使用してキャッシュキーを作成
  const cacheKey = `${author.id}:rep`;

  // このリクエストに対してキャッシュされた結果があるか確認
  if (cache.has(cacheKey)) {
    // キャッシュされた結果が存在する場合、それを返す
    return cache.get(cacheKey);
  }

  const lb = await getReputationLb(10);
  if (lb.length === 0) return "リーダーボードにユーザーがいません";

  let collector = "";
  for (let i = 0; i < lb.length; i++) {
    try {
      const user = await author.client.users.fetch(lb[i].member_id);
      collector += `**#${(i + 1).toString()}** - ${escapeInlineCode(user.tag)} [${lb[i].rep}]\n`;
    } catch (ex) {
      collector += `**#${(i + 1).toString()}** - DeletedUser#0000 [${lb[i].rep}]\n`;
    }
  }

  const embed = new EmbedBuilder()
    .setAuthor({ name: "Reputationリーダーボード" })
    .setColor(EMBED_COLORS.BOT_EMBED)
    .setDescription(collector)
    .setFooter({ text: `リクエスト者: ${author.tag}` });

  // キャッシュに結果を保存し、次回のリクエストに備える
  cache.set(cacheKey, { embeds: [embed] });
  return { embeds: [embed] };
}
