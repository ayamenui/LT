const { EMBED_COLORS } = require("@root/config");

/**
 * @param {import('discord.js').GuildMember} member
 */
module.exports = async (member) => {
  // 権限確認
  if (!member.permissions.has("ManageMessages")) {
    return "プレゼント企画を管理するには、メッセージ管理権限が必要です。";
  }

  // すべてのギブアウェイを検索
  const giveaways = member.client.giveawaysManager.giveaways.filter(
    (g) => g.guildId === member.guild.id && g.ended === false
  );

  // ギブアウェイがない場合
  if (giveaways.length === 0) {
    return "このサーバーでは実行中のプレゼント企画はありません。";
  }

  const description = giveaways.map((g, i) => `${i + 1}. <#${g.channelId}>での${g.prize}`).join("\n");

  try {
    return { embeds: [{ description, color: EMBED_COLORS.GIVEAWAYS }] };
  } catch (error) {
    member.client.logger.error("ギブアウェイ一覧", error);
    return `プレゼント企画を一覧表示中にエラーが発生しました: ${error.message}`;
  }
};
