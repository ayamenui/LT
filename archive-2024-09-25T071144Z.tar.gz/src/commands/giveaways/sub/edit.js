/**
 * @param {import('discord.js').GuildMember} member
 * @param {string} messageId
 * @param {number} addDuration
 * @param {string} newPrize
 * @param {number} newWinnerCount
 */
module.exports = async (member, messageId, addDuration, newPrize, newWinnerCount) => {
  if (!messageId) return "有効なメッセージIDを入力してください。";

  // 権限確認
  if (!member.permissions.has("ManageMessages")) {
    return "プレゼント企画を開始するには、メッセージ管理権限が必要です。";
  }

  // messageIdで検索
  const giveaway = member.client.giveawaysManager.giveaways.find(
    (g) => g.messageId === messageId && g.guildId === member.guild.id
  );

  // ギブアウェイが見つからない場合
  if (!giveaway) return `メッセージID: ${messageId} に該当するプレゼント企画が見つかりません。`;

  try {
    await member.client.giveawaysManager.edit(messageId, {
      addTime: addDuration || 0,
      newPrize: newPrize || giveaway.prize,
      newWinnerCount: newWinnerCount || giveaway.winnerCount,
    });

    return `プレゼント企画が正常に更新されました！`;
  } catch (error) {
    member.client.logger.error("ギブアウェイ編集", error);
    return `プレゼント企画の更新中にエラーが発生しました: ${error.message}`;
  }
};
