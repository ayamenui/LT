const { ChannelType } = require("discord.js");

/**
 * @param {import('discord.js').GuildMember} member
 * @param {import('discord.js').GuildTextBasedChannel} giveawayChannel
 * @param {number} duration
 * @param {string} prize
 * @param {number} winners
 * @param {import('discord.js').User} [host]
 * @param {string[]} [allowedRoles]
 */
module.exports = async (member, giveawayChannel, duration, prize, winners, host, allowedRoles = []) => {
  try {
    if (!host) host = member.user;
    if (!member.permissions.has("ManageMessages")) {
      return "プレゼント企画を開始するには、メッセージ管理権限が必要です。";
    }

    if (!giveawayChannel.type === ChannelType.GuildText) {
      return "プレゼント企画はテキストチャンネルでのみ開始できます。";
    }

    /**
     * @type {import("discord-giveaways").GiveawayStartOptions}
     */
    const options = {
      duration: duration,
      prize,
      winnerCount: winners,
      hostedBy: host,
      thumbnail: "https://i.imgur.com/DJuTuxs.png",
      messages: {
        giveaway: "🎉 **プレゼント企画** 🎉",
        giveawayEnded: "🎉 **プレゼント企画終了** 🎉",
        inviteToParticipate: "🎁でリアクションして参加",
        dropMessage: "🎁でリアクションした人の中から勝者がえらばれます。！",
        hostedBy: `\n主催者: ${host.username}`,
      },
    };

    if (allowedRoles.length > 0) {
      options.exemptMembers = (member) => !member.roles.cache.find((role) => allowedRoles.includes(role.id));
    }

    await member.client.giveawaysManager.start(giveawayChannel, options);
    return `${giveawayChannel}でプレゼント企画が開始されました。`;
  } catch (error) {
    member.client.logger.error("プレゼント企画開始", error);
    return `プレゼント企画を開始中にエラーが発生しました: ${error.message}`;
  }
};
