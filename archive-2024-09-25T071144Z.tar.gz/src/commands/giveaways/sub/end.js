/**
 * @param {import('discord.js').GuildMember} member
 * @param {string} messageId
 */
module.exports = async (member, messageId) => {
  if (!messageId) return "有効なメッセージIDを入力してください。";

  // 権限確認
  if (!member.permissions.has("ManageMessages")) {
    return "プレゼント企画を終了するには、メッセージ管理権限が必要です。";
  }

  // messageIdで検索
  const giveaway = member.client.giveawaysManager.giveaways.find(
    (g) => g.messageId === messageId && g.guildId === member.guild.id
  );

  // ギブアウェイが見つからない場合
  if (!giveaway) return `メッセージID: ${messageId} に該当するプレゼント企画が見つかりません。`;

  // ギブアウェイが終了しているか確認
  if (giveaway.ended) return "このプレゼント企画はすでに終了しています。";

  try {
    await giveaway.end();
    return "成功しました！プレゼント企画は終了しました！";
  } catch (error) {
    member.client.logger.error("プレゼント企画終了", error);
    return `プレゼント企画を終了する際にエラーが発生しました: ${error.message}`;
  }
};
