const { EmbedBuilder, ApplicationCommandOptionType } = require("discord.js");
const { getJson } = require("@helpers/HttpUtils");
const { EMBED_COLORS } = require("@root/config");
const NekosLife = require("nekos.life");
const neko = new NekosLife();

const choices = ["ハグ", "キス", "抱きしめる", "食べさせる", "撫でる", "つつく", "平手打ち", "ドヤ顔", "くすぐる", "ウィンク"];

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "リアクション",
  description: "アニメのリアクション",
  enabled: true,
  category: "アニメ",
  cooldown: 5,
  command: {
    enabled: true,
    minArgsCount: 1,
    usage: "[リアクション]",
  },
  slashCommand: {
    enabled: true,
    options: [
      {
        name: "カテゴリー",
        description: "リアクションの種類",
        type: ApplicationCommandOptionType.String,
        required: true,
        choices: choices.map((ch) => ({ name: ch, value: ch })),
      },
    ],
  },

  async messageRun(message, args) {
    const category = args[0].toLowerCase();
    if (!choices.includes(category)) {
      return message.safeReply(`無効な選択: \`${category}\`。\n利用可能なリアクション: ${choices.join(", ")}`);
    }

    const embed = await genReaction(category, message.author);
    await message.safeReply({ embeds: [embed] });
  },

  async interactionRun(interaction) {
    const choice = interaction.options.getString("category");
    const embed = await genReaction(choice, interaction.user);
    await interaction.followUp({ embeds: [embed] });
  },
};

const genReaction = async (category, user) => {
  try {
    let imageUrl;

    // some-random api
    if (category === "ウィンク") {
      const response = await getJson("https://some-random-api.com/animu/wink");
      if (!response.success) throw new Error("APIエラー");
      imageUrl = response.data.link;
    }

    // neko api
    else {
      imageUrl = (await neko[category]()).url;
    }

    return new EmbedBuilder()
      .setImage(imageUrl)
      .setColor("ランダム")
      .setFooter({ text: `リクエスト: ${user.tag}` });
  } catch (ex) {
    return new EmbedBuilder()
      .setColor(EMBED_COLORS.ERROR)
      .setDescription("メームを取得できませんでした。もう一度試してください！")
      .setFooter({ text: `リクエスト: ${user.tag}` });
  }
};
