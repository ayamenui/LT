const { deafenTarget } = require("@helpers/ModUtils");

module.exports = async ({ member }, target, reason) => {
  const response = await deafenTarget(member, target, reason);
  if (typeof response === "boolean") {
    return `${target.user.username} はこのサーバーでミュートされました`;
  }
  if (response === "MEMBER_PERM") {
    return `${target.user.username} をミュートにする権限がありません`;
  }
  if (response === "BOT_PERM") {
    return `${target.user.username} をミュートにする権限がありません`;
  }
  if (response === "NO_VOICE") {
    return `${target.user.username} はどのボイスチャンネルにも参加していません`;
  }
  if (response === "ALREADY_DEAFENED") {
    return `${target.user.username} はすでにミュートされています`;
  }
  return `${target.user.username} のミュートに失敗しました`;
};
