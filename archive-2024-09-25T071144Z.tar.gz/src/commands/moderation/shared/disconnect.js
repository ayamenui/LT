const { disconnectTarget } = require("@helpers/ModUtils");

module.exports = async ({ member }, target, reason) => {
  const response = await disconnectTarget(member, target, reason);
  if (typeof response === "boolean") {
    return `${target.user.username} はボイスチャンネルから切断されました`;
  }
  if (response === "MEMBER_PERM") {
    return `${target.user.username} を切断する権限がありません`;
  }
  if (response === "BOT_PERM") {
    return `${target.user.username} を切断する権限がありません`;
  }
  if (response === "NO_VOICE") {
    return `${target.user.username} はどのボイスチャンネルにも参加していません`;
  }
  return `${target.user.username} の切断に失敗しました`;
};
