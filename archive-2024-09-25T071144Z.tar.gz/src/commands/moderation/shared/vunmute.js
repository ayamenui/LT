const { vUnmuteTarget } = require("@helpers/ModUtils");

module.exports = async ({ member }, target, reason) => {
  const response = await vUnmuteTarget(member, target, reason);
  if (typeof response === "boolean") {
    return `${target.user.username} のボイスミュートが解除されました`;
  }
  if (response === "MEMBER_PERM") {
    return `${target.user.username} のボイスミュート解除の権限がありません`;
  }
  if (response === "BOT_PERM") {
    return `${target.user.username} のボイスミュート解除の権限がありません`;
  }
  if (response === "NO_VOICE") {
    return `${target.user.username} はどのボイスチャンネルにも参加していません`;
  }
  if (response === "NOT_MUTED") {
    return `${target.user.username} はボイスミュートされていません`;
  }
  return `${target.user.username} のボイスミュート解除に失敗しました`;
};
