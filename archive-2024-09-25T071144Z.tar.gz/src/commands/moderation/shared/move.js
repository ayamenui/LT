const { moveTarget } = require("@helpers/ModUtils");

module.exports = async ({ member }, target, reason, channel) => {
  const response = await moveTarget(member, target, reason, channel);
  if (typeof response === "boolean") {
    return `${target.user.username} を ${channel} に移動しました`;
  }
  if (response === "MEMBER_PERM") {
    return `${target.user.username} を切断する権限がありません`;
  }
  if (response === "BOT_PERM") {
    return `${target.user.username} を切断する権限がありません`;
  }
  if (response === "NO_VOICE") {
    return `${target.user.username} はどのボイスチャンネルにも参加していません`;
  }
  if (response === "TARGET_PERM") {
    return `${target.user.username} は ${channel} に参加する権限がありません`;
  }
  if (response === "ALREADY_IN_CHANNEL") {
    return `${target.user.username} はすでに ${channel} に接続しています`;
  }
  return `${target.user.username} を ${channel} に移動するのに失敗しました`;
};
