const { timeoutTarget } = require("@helpers/ModUtils");
const { ApplicationCommandOptionType } = require("discord.js");
const ems = require("enhanced-ms");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "timeout",
  description: "指定されたメンバーをタイムアウトします",
  category: "MODERATION",
  botPermissions: ["ModerateMembers"],
  userPermissions: ["ModerateMembers"],
  command: {
    enabled: true,
    aliases: ["mute"],
    usage: "<ID|@member> <duration> [reason]",
    minArgsCount: 2,
  },
  slashCommand: {
    enabled: true,
    options: [
      {
        name: "user",
        description: "タイムアウトする対象のメンバー",
        type: ApplicationCommandOptionType.User,
        required: true,
      },
      {
        name: "duration",
        description: "メンバーをタイムアウトさせる期間",
        type: ApplicationCommandOptionType.String,
        required: true,
      },
      {
        name: "reason",
        description: "タイムアウトの理由",
        type: ApplicationCommandOptionType.String,
        required: false,
      },
    ],
  },

  async messageRun(message, args) {
    const target = await message.guild.resolveMember(args[0], true);
    if (!target) return message.safeReply(`指定されたユーザー ${args[0]} が見つかりませんでした`);

    // 時間の解析
    const ms = ems(args[1]);
    if (!ms) return message.safeReply("有効な期間を指定してください。例: 1d/1h/1m/1s");

    const reason = args.slice(2).join(" ").trim();
    const response = await timeout(message.member, target, ms, reason);
    await message.safeReply(response);
  },

  async interactionRun(interaction) {
    const user = interaction.options.getUser("user");

    // 時間の解析
    const duration = interaction.options.getString("duration");
    const ms = ems(duration);
    if (!ms) return interaction.followUp("有効な期間を指定してください。例: 1d/1h/1m/1s");

    const reason = interaction.options.getString("reason");
    const target = await interaction.guild.members.fetch(user.id);

    const response = await timeout(interaction.member, target, ms, reason);
    await interaction.followUp(response);
  },
};

async function timeout(issuer, target, ms, reason) {
  if (isNaN(ms)) return "有効な期間を指定してください。例: 1d/1h/1m/1s";
  const response = await timeoutTarget(issuer, target, ms, reason);
  if (typeof response === "boolean") return `${target.user.username} がタイムアウトされました!`;
  if (response === "BOT_PERM") return `私は ${target.user.username} をタイムアウトする権限がありません`;
  else if (response === "MEMBER_PERM") return `あなたには ${target.user.username} をタイムアウトする権限がありません`;
  else if (response === "ALREADY_TIMEOUT") return `${target.user.username} はすでにタイムアウトされています!`;
  else return `${target.user.username} のタイムアウトに失敗しました`;
}
