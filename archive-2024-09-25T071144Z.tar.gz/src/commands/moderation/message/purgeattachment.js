const { purgeMessages } = require("@helpers/ModUtils");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "purgeattach",
  description: "添付ファイル付きのメッセージを指定された数だけ削除する",
  category: "MODERATION",
  userPermissions: ["ManageMessages"],
  botPermissions: ["ManageMessages", "ReadMessageHistory"],
  command: {
    enabled: true,
    usage: "[数]",
    aliases: ["purgeattachment", "purgeattachments"],
  },

  async messageRun(message, args) {
    const amount = args[0] || 99;

    if (amount) {
      if (isNaN(amount)) return message.safeReply("数字のみが許可されています");
      if (parseInt(amount) > 99) return message.safeReply("削除できるメッセージの最大数は99です");
    }

    const { channel } = message;
    const response = await purgeMessages(message.member, message.channel, "ATTACHMENT", amount);

    if (typeof response === "number") {
      return channel.safeSend(`メッセージ ${response} 件を正常に削除しました`, 5);
    } else if (response === "BOT_PERM") {
      return message.safeReply("メッセージを削除するための `Read Message History` と `Manage Messages` の権限がありません", 5);
    } else if (response === "MEMBER_PERM") {
      return message.safeReply("メッセージを削除するための `Read Message History` と `Manage Messages` の権限がありません", 5);
    } else if (response === "NO_MESSAGES") {
      return channel.safeSend("削除できるメッセージが見つかりませんでした", 5);
    } else {
      return message.safeReply(`エラーが発生しました！メッセージの削除に失敗しました`);
    }
  },
};
