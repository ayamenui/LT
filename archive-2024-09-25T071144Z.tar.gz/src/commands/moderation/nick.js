const { canModerate } = require("@helpers/ModUtils");
const { ApplicationCommandOptionType } = require("discord.js");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "nick",
  description: "ニックネーム管理コマンド",
  category: "MODERATION",
  botPermissions: ["ManageNicknames"],
  userPermissions: ["ManageNicknames"],
  command: {
    enabled: true,
    minArgsCount: 2,
    subcommands: [
      {
        trigger: "set <@member> <name>",
        description: "指定したメンバーのニックネームを設定します",
      },
      {
        trigger: "reset <@member>",
        description: "メンバーのニックネームをリセットします",
      },
    ],
  },
  slashCommand: {
    enabled: true,
    options: [
      {
        name: "set",
        description: "メンバーのニックネームを変更します",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "user",
            description: "ニックネームを設定するメンバー",
            type: ApplicationCommandOptionType.User,
            required: true,
          },
          {
            name: "name",
            description: "設定するニックネーム",
            type: ApplicationCommandOptionType.String,
            required: true,
          },
        ],
      },
      {
        name: "reset",
        description: "メンバーのニックネームをリセットします",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "user",
            description: "ニックネームをリセットするメンバー",
            type: ApplicationCommandOptionType.User,
            required: true,
          },
        ],
      },
    ],
  },

  async messageRun(message, args) {
    const sub = args[0].toLowerCase();

    if (sub === "set") {
      const target = await message.guild.resolveMember(args[1]);
      if (!target) return message.safeReply("一致するメンバーが見つかりませんでした");
      const name = args.slice(2).join(" ");
      if (!name) return message.safeReply("ニックネームを指定してください");

      const response = await nickname(message, target, name);
      return message.safeReply(response);
    }

    //
    else if (sub === "reset") {
      const target = await message.guild.resolveMember(args[1]);
      if (!target) return message.safeReply("一致するメンバーが見つかりませんでした");

      const response = await nickname(message, target);
      return message.safeReply(response);
    }
  },

  async interactionRun(interaction) {
    const name = interaction.options.getString("name");
    const target = await interaction.guild.members.fetch(interaction.options.getUser("user"));

    const response = await nickname(interaction, target, name);
    await interaction.followUp(response);
  },
};

async function nickname({ member, guild }, target, name) {
  if (!canModerate(member, target)) {
    return `Oops! あなたは ${target.user.username} のニックネームを管理できません`;
  }
  if (!canModerate(guild.members.me, target)) {
    return `Oops! 私は ${target.user.username} のニックネームを管理できません`;
  }

  try {
    await target.setNickname(name);
    return `成功しました: ${target.user.username} のニックネームを ${name ? "変更" : "リセット"} しました`;
  } catch (ex) {
    return `失敗しました: ${target.displayName} のニックネームを ${name ? "変更" : "リセット"} できませんでした。正しい名前を指定しましたか？`;
  }
}
