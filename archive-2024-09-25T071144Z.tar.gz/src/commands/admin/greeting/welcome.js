const { isHex } = require("@helpers/Utils");
const { buildGreeting } = require("@handlers/greeting");
const { ApplicationCommandOptionType, ChannelType } = require("discord.js");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "welcome",
  description: "ウェルカムメッセージの設定",
  category: "ADMIN",
  userPermissions: ["ManageGuild"],
  command: {
    enabled: true,
    minArgsCount: 1,
    subcommands: [
      {
        trigger: "status <on|off>",
        description: "ウェルカムメッセージを有効または無効にします",
      },
      {
        trigger: "channel <#channel>",
        description: "ウェルカムメッセージのチャンネルを設定します",
      },
      {
        trigger: "preview",
        description: "設定されたウェルカムメッセージをプレビューします",
      },
      {
        trigger: "desc <text>",
        description: "埋め込みの説明を設定します",
      },
      {
        trigger: "thumbnail <ON|OFF>",
        description: "埋め込みのサムネイルを有効/無効にします",
      },
      {
        trigger: "color <hexcolor>",
        description: "埋め込みの色を設定します",
      },
      {
        trigger: "footer <text>",
        description: "埋め込みのフッター内容を設定します",
      },
      {
        trigger: "image <url>",
        description: "埋め込みの画像を設定します",
      },
    ],
  },
  slashCommand: {
    enabled: true,
    ephemeral: true,
    options: [
      {
        name: "status",
        description: "ウェルカムメッセージを有効または無効にします",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "status",
            description: "有効または無効",
            required: true,
            type: ApplicationCommandOptionType.String,
            choices: [
              {
                name: "ON",
                value: "ON",
              },
              {
                name: "OFF",
                value: "OFF",
              },
            ],
          },
        ],
      },
      {
        name: "preview",
        description: "設定されたウェルカムメッセージをプレビューします",
        type: ApplicationCommandOptionType.Subcommand,
      },
      {
        name: "channel",
        description: "ウェルカムメッセージのチャンネルを設定します",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "channel",
            description: "チャンネル名",
            type: ApplicationCommandOptionType.Channel,
            channelTypes: [ChannelType.GuildText],
            required: true,
          },
        ],
      },
      {
        name: "desc",
        description: "埋め込みの説明を設定します",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "content",
            description: "説明の内容",
            type: ApplicationCommandOptionType.String,
            required: true,
          },
        ],
      },
      {
        name: "thumbnail",
        description: "埋め込みのサムネイルを設定します",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "status",
            description: "サムネイルの状態",
            type: ApplicationCommandOptionType.String,
            required: true,
            choices: [
              {
                name: "ON",
                value: "ON",
              },
              {
                name: "OFF",
                value: "OFF",
              },
            ],
          },
        ],
      },
      {
        name: "color",
        description: "埋め込みの色を設定します",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "hex-code",
            description: "16進数のカラーコード",
            type: ApplicationCommandOptionType.String,
            required: true,
          },
        ],
      },
      {
        name: "footer",
        description: "埋め込みのフッターを設定します",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "content",
            description: "フッターの内容",
            type: ApplicationCommandOptionType.String,
            required: true,
          },
        ],
      },
      {
        name: "image",
        description: "埋め込みの画像を設定します",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "url",
            description: "画像のURL",
            type: ApplicationCommandOptionType.String,
            required: true,
          },
        ],
      },
    ],
  },

  async messageRun(message, args, data) {
    const type = args[0].toLowerCase();
    const settings = data.settings;
    let response;

    // プレビュー
    if (type === "preview") {
      response = await sendPreview(settings, message.member);
    }

    // ステータス
    else if (type === "status") {
      const status = args[1]?.toUpperCase();
      if (!status || !["ON", "OFF"].includes(status))
        return message.safeReply("無効なステータスです。値は `on/off` である必要があります");
      response = await setStatus(settings, status);
    }

    // チャンネル
    else if (type === "channel") {
      const channel = message.mentions.channels.first();
      response = await setChannel(settings, channel);
    }

    // 説明
    else if (type === "desc") {
      if (args.length < 2) return message.safeReply("引数が不足しています！有効な内容を提供してください");
      const desc = args.slice(1).join(" ");
      response = await setDescription(settings, desc);
    }

    // サムネイル
    else if (type === "thumbnail") {
      const status = args[1]?.toUpperCase();
      if (!status || !["ON", "OFF"].includes(status))
        return message.safeReply("無効なステータスです。値は `on/off` である必要があります");
      response = await setThumbnail(settings, status);
    }

    // 色
    else if (type === "color") {
      const color = args[1];
      if (!color || !isHex(color)) return message.safeReply("無効な色です。有効な16進数のカラーコードを指定してください");
      response = await setColor(settings, color);
    }

    // フッター
    else if (type === "footer") {
      if (args.length < 2) return message.safeReply("引数が不足しています！有効な内容を提供してください");
      const content = args.slice(1).join(" ");
      response = await setFooter(settings, content);
    }

    // 画像
    else if (type === "image") {
      const url = args[1];
      if (!url) return message.safeReply("無効な画像URLです。有効なURLを指定してください");
      response = await setImage(settings, url);
    }

    //
    else response = "無効なコマンドの使用です！";
    return message.safeReply(response);
  },

  async interactionRun(interaction, data) {
    const sub = interaction.options.getSubcommand();
    const settings = data.settings;

    let response;
    switch (sub) {
      case "preview":
        response = await sendPreview(settings, interaction.member);
        break;

      case "status":
        response = await setStatus(settings, interaction.options.getString("status"));
        break;

      case "channel":
        response = await setChannel(settings, interaction.options.getChannel("channel"));
        break;

      case "desc":
        response = await setDescription(settings, interaction.options.getString("content"));
        break;

      case "thumbnail":
        response = await setThumbnail(settings, interaction.options.getString("status"));
        break;

      case "color":
        response = await setColor(settings, interaction.options.getString("hex-code"));
        break;

      case "footer":
        response = await setFooter(settings, interaction.options.getString("content"));
        break;

      case "image":
        response = await setImage(settings, interaction.options.getString("url"));
        break;

      default:
        response = "無効なサブコマンドです";
    }

    return interaction.followUp(response);
  },
};

async function sendPreview(settings, member) {
  if (!settings.welcome?.enabled) return "このサーバーではウェルカムメッセージが有効になっていません";

  const targetChannel = member.guild.channels.cache.get(settings.welcome.channel);
  if (!targetChannel) return "ウェルカムメッセージを送信するチャンネルが設定されていません";

  const response = await buildGreeting(member, "WELCOME", settings.welcome);
  await targetChannel.safeSend(response);

  return `${targetChannel.toString()}にウェルカムプレビューを送信しました`;
}

async function setStatus(settings, status) {
  const enabled = status.toUpperCase() === "ON" ? true : false;
  settings.welcome.enabled = enabled;
  await settings.save();
  return `設定が保存されました！ウェルカムメッセージは${enabled ? "有効" : "無効"}になりました`;
}

async function setChannel(settings, channel) {
  if (!channel.canSendEmbeds()) {
    return (
      "そのチャンネルには挨拶を送信できません。`Write Messages` と `Embed Links` の権限が必要です " +
      channel.toString()
    );
  }
  settings.welcome.channel = channel.id;
  await settings.save();
  return `設定が保存されました！ウェルカムメッセージは ${channel ? channel.toString() : "見つかりません"} に送信されます`;
}

async function setDescription(settings, desc) {
  settings.welcome.embed.description = desc;
  await settings.save();
  return "設定が保存されました！ウェルカムメッセージが更新されました";
}

async function setThumbnail(settings, status) {
  settings.welcome.embed.thumbnail = status.toUpperCase() === "ON" ? true : false;
  await settings.save();
  return "設定が保存されました！ウェルカムメッセージが更新されました";
}

async function setColor(settings, color) {
  settings.welcome.embed.color = color;
  await settings.save();
  return "設定が保存されました！ウェルカムメッセージが更新されました";
}

async function setFooter(settings, content) {
  settings.welcome.embed.footer = content;
  await settings.save();
  return "設定が保存されました！ウェルカムメッセージが更新されました";
}

async function setImage(settings, url) {
  settings.welcome.embed.image = url;
  await settings.save();
  return "設定が保存されました！ウェルカムメッセージが更新されました";
}
