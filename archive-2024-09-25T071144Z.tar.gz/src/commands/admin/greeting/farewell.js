const { isHex } = require("@helpers/Utils");
const { buildGreeting } = require("@handlers/greeting");
const { ApplicationCommandOptionType, ChannelType } = require("discord.js");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "farewell",
  description: "さようならメッセージの設定",
  category: "ADMIN",
  userPermissions: ["ManageGuild"],
  command: {
    enabled: true,
    minArgsCount: 1,
    subcommands: [
      {
        trigger: "status <on|off>",
        description: "さようならメッセージを有効または無効にする",
      },
      {
        trigger: "channel <#channel>",
        description: "さようならメッセージを送信するチャンネルを設定する",
      },
      {
        trigger: "preview",
        description: "設定されたさようならメッセージをプレビューする",
      },
      {
        trigger: "desc <text>",
        description: "埋め込みメッセージの説明を設定する",
      },
      {
        trigger: "thumbnail <ON|OFF>",
        description: "埋め込みメッセージのサムネイルを有効または無効にする",
      },
      {
        trigger: "color <hexcolor>",
        description: "埋め込みメッセージの色を設定する",
      },
      {
        trigger: "footer <text>",
        description: "埋め込みメッセージのフッター内容を設定する",
      },
      {
        trigger: "image <url>",
        description: "埋め込みメッセージの画像を設定する",
      },
    ],
  },
  slashCommand: {
    enabled: true,
    ephemeral: true,
    options: [
      {
        name: "status",
        description: "さようならメッセージを有効または無効にする",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "status",
            description: "有効または無効",
            required: true,
            type: ApplicationCommandOptionType.String,
            choices: [
              {
                name: "ON",
                value: "ON",
              },
              {
                name: "OFF",
                value: "OFF",
              },
            ],
          },
        ],
      },
      {
        name: "preview",
        description: "設定されたさようならメッセージをプレビューする",
        type: ApplicationCommandOptionType.Subcommand,
      },
      {
        name: "channel",
        description: "さようならメッセージのチャンネルを設定する",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "channel",
            description: "チャンネル名",
            type: ApplicationCommandOptionType.Channel,
            channelTypes: [ChannelType.GuildText],
            required: true,
          },
        ],
      },
      {
        name: "desc",
        description: "埋め込みメッセージの説明を設定する",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "content",
            description: "説明の内容",
            type: ApplicationCommandOptionType.String,
            required: true,
          },
        ],
      },
      {
        name: "thumbnail",
        description: "埋め込みメッセージのサムネイルを設定する",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "status",
            description: "サムネイルの状態",
            type: ApplicationCommandOptionType.String,
            required: true,
            choices: [
              {
                name: "ON",
                value: "ON",
              },
              {
                name: "OFF",
                value: "OFF",
              },
            ],
          },
        ],
      },
      {
        name: "color",
        description: "埋め込みメッセージの色を設定する",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "hex-code",
            description: "HEXカラコード",
            type: ApplicationCommandOptionType.String,
            required: true,
          },
        ],
      },
      {
        name: "footer",
        description: "埋め込みメッセージのフッターを設定する",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "content",
            description: "フッターの内容",
            type: ApplicationCommandOptionType.String,
            required: true,
          },
        ],
      },
      {
        name: "image",
        description: "埋め込みメッセージの画像を設定する",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "url",
            description: "画像のURL",
            type: ApplicationCommandOptionType.String,
            required: true,
          },
        ],
      },
    ],
  },

  async messageRun(message, args, data) {
    const type = args[0].toLowerCase();
    const settings = data.settings;
    let response;

    // プレビュー
    if (type === "preview") {
      response = await sendPreview(settings, message.member);
    }

    // ステータス
    else if (type === "status") {
      const status = args[1]?.toUpperCase();
      if (!status || !["ON", "OFF"].includes(status))
        return message.safeReply("無効なステータスです。値は `on/off` でなければなりません");
      response = await setStatus(settings, status);
    }

    // チャンネル
    else if (type === "channel") {
      const channel = message.mentions.channels.first();
      response = await setChannel(settings, channel);
    }

    // 説明
    else if (type === "desc") {
      if (args.length < 2) return message.safeReply("引数が不足しています！有効な内容を提供してください");
      const desc = args.slice(1).join(" ");
      response = await setDescription(settings, desc);
    }

    // サムネイル
    else if (type === "thumbnail") {
      const status = args[1]?.toUpperCase();
      if (!status || !["ON", "OFF"].includes(status))
        return message.safeReply("無効なステータスです。値は `on/off` でなければなりません");
      response = await setThumbnail(settings, status);
    }

    // 色
    else if (type === "color") {
      const color = args[1];
      if (!color || !isHex(color)) return message.safeReply("無効な色です。値は有効なHEXカラーでなければなりません");
      response = await setColor(settings, color);
    }

    // フッター
    else if (type === "footer") {
      if (args.length < 2) return message.safeReply("引数が不足しています！有効な内容を提供してください");
      const content = args.slice(1).join(" ");
      response = await setFooter(settings, content);
    }

    // 画像
    else if (type === "image") {
      const url = args[1];
      if (!url) return message.safeReply("無効な画像URLです。有効なURLを提供してください");
      response = await setImage(settings, url);
    }

    //
    else response = "無効なコマンドの使用です！";
    return message.safeReply(response);
  },

  async interactionRun(interaction, data) {
    const sub = interaction.options.getSubcommand();
    const settings = data.settings;

    let response;
    switch (sub) {
      case "preview":
        response = await sendPreview(settings, interaction.member);
        break;

      case "status":
        response = await setStatus(settings, interaction.options.getString("status"));
        break;

      case "channel":
        response = await setChannel(settings, interaction.options.getChannel("channel"));
        break;

      case "desc":
        response = await setDescription(settings, interaction.options.getString("content"));
        break;

      case "thumbnail":
        response = await setThumbnail(settings, interaction.options.getString("status"));
        break;

      case "color":
        response = await setColor(settings, interaction.options.getString("hex-code"));
        break;

      case "footer":
        response = await setFooter(settings, interaction.options.getString("content"));
        break;

      case "image":
        response = await setImage(settings, interaction.options.getString("url"));
        break;

      default:
        response = "無効なサブコマンドです";
    }

    return interaction.followUp(response);
  },
};

async function sendPreview(settings, member) {
  if (!settings.farewell?.enabled) return "このサーバーではさようならメッセージが有効ではありません";

  const targetChannel = member.guild.channels.cache.get(settings.farewell.channel);
  if (!targetChannel) return "さようならメッセージを送信するチャンネルが設定されていません";

  const response = await buildGreeting(member, "FAREWELL", settings.farewell);
  await targetChannel.safeSend(response);

  return `${targetChannel.toString()}にさようならメッセージのプレビューを送信しました`;
}

async function setStatus(settings, status) {
  const enabled = status.toUpperCase() === "ON" ? true : false;
  settings.farewell.enabled = enabled;
  await settings.save();
  return `設定を保存しました！さようならメッセージは${status ? "有効" : "無効"}になりました`;
}

async function setChannel(settings, channel) {
  if (!channel.canSendEmbeds()) {
    return (
      "そのチャンネルにメッセージを送信できません。`メッセージの送信`と`埋め込みリンク`の権限が必要です。" +
      channel.toString()
    );
  }
  settings.farewell.channel = channel.id;
  await settings.save();
  return `設定を保存しました！さようならメッセージは${channel ? channel.toString() : "チャンネルが見つかりません"}に送信されます`;
}

async function setDescription(settings, desc) {
  settings.farewell.embed.description = desc;
  await settings.save();
  return "設定を保存しました！さようならメッセージが更新されました";
}

async function setThumbnail(settings, status) {
  settings.farewell.embed.thumbnail = status.toUpperCase() === "ON" ? true : false;
  await settings.save();
  return "設定を保存しました！さようならメッセージが更新されました";
}

async function setColor(settings, color) {
  settings.farewell.embed.color = color;
  await settings.save();
  return "設定を保存しました！さようならメッセージが更新されました";
}

async function setFooter(settings, content) {
  settings.farewell.embed.footer = content;
  await settings.save();
  return "設定を保存しました！さようならメッセージが更新されました";
}

async function setImage(settings, url) {
  settings.farewell.embed.image = url;
  await settings.save();
  return "設定を保存しました！さようならメッセージが更新されました";
}
