const { ApplicationCommandOptionType } = require("discord.js");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "autodelete",
  description: "サーバーの自動削除設定を管理する",
  category: "AUTOMOD",
  userPermissions: ["ManageGuild"],
  command: {
    enabled: true,
    minArgsCount: 2,
    subcommands: [
      {
        trigger: "attachments <on|off>",
        description: "メッセージ内の添付ファイルを許可または禁止する",
      },
      {
        trigger: "invites <on|off>",
        description: "メッセージ内の招待リンクを許可または禁止する",
      },
      {
        trigger: "links <on|off>",
        description: "メッセージ内のリンクを許可または禁止する",
      },
      {
        trigger: "maxlines <number>",
        description: "メッセージあたりの最大行数を設定する [0で無効化]",
      },
    ],
  },
  slashCommand: {
    enabled: true,
    ephemeral: true,
    options: [
      {
        name: "attachments",
        description: "メッセージ内の添付ファイルを許可または禁止する",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "status",
            description: "設定の状態",
            required: true,
            type: ApplicationCommandOptionType.String,
            choices: [
              {
                name: "ON",
                value: "ON",
              },
              {
                name: "OFF",
                value: "OFF",
              },
            ],
          },
        ],
      },
      {
        name: "invites",
        description: "メッセージ内のDiscord招待リンクを許可または禁止する",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "status",
            description: "設定の状態",
            required: true,
            type: ApplicationCommandOptionType.String,
            choices: [
              {
                name: "ON",
                value: "ON",
              },
              {
                name: "OFF",
                value: "OFF",
              },
            ],
          },
        ],
      },
      {
        name: "links",
        description: "メッセージ内のリンクを許可または禁止する",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "status",
            description: "設定の状態",
            required: true,
            type: ApplicationCommandOptionType.String,
            choices: [
              {
                name: "ON",
                value: "ON",
              },
              {
                name: "OFF",
                value: "OFF",
              },
            ],
          },
        ],
      },
      {
        name: "maxlines",
        description: "メッセージの最大行数を設定する",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "amount",
            description: "設定の行数 (0で無効化)",
            required: true,
            type: ApplicationCommandOptionType.Integer,
          },
        ],
      },
    ],
  },

  async messageRun(message, args, data) {
    const settings = data.settings;
    const sub = args[0].toLowerCase();
    let response;

    if (sub == "attachments") {
      const status = args[1].toLowerCase();
      if (!["on", "off"].includes(status)) return message.safeReply("無効なステータスです。値は `on/off` でなければなりません。");
      response = await antiAttachments(settings, status);
    }

    //
    else if (sub === "invites") {
      const status = args[1].toLowerCase();
      if (!["on", "off"].includes(status)) return message.safeReply("無効なステータスです。値は `on/off` でなければなりません。");
      response = await antiInvites(settings, status);
    }

    //
    else if (sub == "links") {
      const status = args[1].toLowerCase();
      if (!["on", "off"].includes(status)) return message.safeReply("無効なステータスです。値は `on/off` でなければなりません。");
      response = await antilinks(settings, status);
    }

    //
    else if (sub === "maxlines") {
      const max = args[1];
      if (isNaN(max) || Number.parseInt(max) < 1) {
        return message.safeReply("最大行数は有効な数値で、1以上である必要があります。");
      }
      response = await maxLines(settings, max);
    }

    //
    else response = "コマンドの使用が無効です！";
    await message.safeReply(response);
  },

  async interactionRun(interaction, data) {
    const sub = interaction.options.getSubcommand();
    const settings = data.settings;
    let response;

    if (sub == "attachments") {
      response = await antiAttachments(settings, interaction.options.getString("status"));
    } else if (sub === "invites") response = await antiInvites(settings, interaction.options.getString("status"));
    else if (sub == "links") response = await antilinks(settings, interaction.options.getString("status"));
    else if (sub === "maxlines") response = await maxLines(settings, interaction.options.getInteger("amount"));
    else response = "コマンドの使用が無効です！";

    await interaction.followUp(response);
  },
};

async function antiAttachments(settings, input) {
  const status = input.toUpperCase() === "ON" ? true : false;
  settings.automod.anti_attachments = status;
  await settings.save();
  return `メッセージ${status ? "に添付ファイルが含まれる場合は自動的に削除されます" : "添付ファイルはフィルタリングされなくなります"}`;
}

async function antiInvites(settings, input) {
  const status = input.toUpperCase() === "ON" ? true : false;
  settings.automod.anti_invites = status;
  await settings.save();
  return `メッセージ${status ? "にDiscord招待リンクが含まれる場合は自動的に削除されます" : "Discord招待リンクはフィルタリングされなくなります"}`;
}

async function antilinks(settings, input) {
  const status = input.toUpperCase() === "ON" ? true : false;
  settings.automod.anti_links = status;
  await settings.save();
  return `メッセージ${status ? "にリンクが含まれる場合は自動的に削除されます" : "リンクはフィルタリングされなくなります"}`;
}

async function maxLines(settings, input) {
  const lines = Number.parseInt(input);
  if (isNaN(lines)) return "有効な数値を入力してください";

  settings.automod.max_lines = lines;
  await settings.save();
  return `${
    input === 0
      ? "最大行数の制限が無効化されました"
      : `\`${input}\`行を超えるメッセージは自動的に削除されます`
  }`;
}
