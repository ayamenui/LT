const { EmbedBuilder, ApplicationCommandOptionType, ChannelType } = require("discord.js");
const { EMBED_COLORS } = require("@root/config.js");
const { stripIndent } = require("common-tags");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "automod",
  description: "さまざまなオートモデレーション設定を管理",
  category: "AUTOMOD",
  userPermissions: ["ManageGuild"],
  command: {
    enabled: true,
    minArgsCount: 1,
    subcommands: [
      {
        trigger: "status",
        description: "このサーバーのオートモデレーション設定を確認",
      },
      {
        trigger: "strikes <number>",
        description: "アクションが行われる前にメンバーが受け取るストライクの最大数を設定",
      },
      {
        trigger: "action <TIMEOUT|KICK|BAN>",
        description: "最大ストライク後に行われるアクションを設定",
      },
      {
        trigger: "debug <on|off>",
        description: "管理者やモデレーターが送信したメッセージに対するオートモデレーションをオン/オフにする",
      },
      {
        trigger: "whitelist",
        description: "ホワイトリストに登録されたチャンネルを表示",
      },
      {
        trigger: "whitelistadd <channel>",
        description: "チャンネルをホワイトリストに追加",
      },
      {
        trigger: "whitelistremove <channel>",
        description: "ホワイトリストからチャンネルを削除",
      },
    ],
  },
  slashCommand: {
    enabled: true,
    ephemeral: true,
    options: [
      {
        name: "status",
        description: "オートモデレーション設定を確認",
        type: ApplicationCommandOptionType.Subcommand,
      },
      {
        name: "strikes",
        description: "アクションが行われる前の最大ストライク数を設定",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "amount",
            description: "ストライク数（デフォルトは5）",
            required: true,
            type: ApplicationCommandOptionType.Integer,
          },
        ],
      },
      {
        name: "action",
        description: "最大ストライク後に行われるアクションを設定",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "action",
            description: "実行するアクション",
            type: ApplicationCommandOptionType.String,
            required: true,
            choices: [
              {
                name: "TIMEOUT",
                value: "TIMEOUT",
              },
              {
                name: "KICK",
                value: "KICK",
              },
              {
                name: "BAN",
                value: "BAN",
              },
            ],
          },
        ],
      },
      {
        name: "debug",
        description: "管理者およびモデレーターが送信したメッセージに対するオートモデレーションを有効/無効にする",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "status",
            description: "設定状況",
            required: true,
            type: ApplicationCommandOptionType.String,
            choices: [
              {
                name: "ON",
                value: "ON",
              },
              {
                name: "OFF",
                value: "OFF",
              },
            ],
          },
        ],
      },
      {
        name: "whitelist",
        description: "ホワイトリストに登録されたチャンネルを表示",
        type: ApplicationCommandOptionType.Subcommand,
      },
      {
        name: "whitelistadd",
        description: "チャンネルをホワイトリストに追加",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "channel",
            description: "追加するチャンネル",
            required: true,
            type: ApplicationCommandOptionType.Channel,
            channelTypes: [ChannelType.GuildText],
          },
        ],
      },
      {
        name: "whitelistremove",
        description: "ホワイトリストからチャンネルを削除",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "channel",
            description: "削除するチャンネル",
            required: true,
            type: ApplicationCommandOptionType.Channel,
            channelTypes: [ChannelType.GuildText],
          },
        ],
      },
    ],
  },

  async messageRun(message, args, data) {
    const input = args[0].toLowerCase();
    const settings = data.settings;

    let response;
    if (input === "status") {
      response = await getStatus(settings, message.guild);
    } else if (input === "strikes") {
      const strikes = args[1];
      if (isNaN(strikes) || Number.parseInt(strikes) < 1) {
        return message.safeReply("ストライクは1以上の有効な数字である必要があります");
      }
      response = await setStrikes(settings, strikes);
    } else if (input === "action") {
      const action = args[1].toUpperCase();
      if (!action || !["TIMEOUT", "KICK", "BAN"].includes(action))
        return message.safeReply("無効なアクションです。アクションは `Timeout`/`Kick`/`Ban` のいずれかである必要があります");
      response = await setAction(settings, message.guild, action);
    } else if (input === "debug") {
      const status = args[1].toLowerCase();
      if (!["on", "off"].includes(status)) return message.safeReply("無効な状態です。値は `on/off` である必要があります");
      response = await setDebug(settings, status);
    }

    // whitelist
    else if (input === "whitelist") {
      response = getWhitelist(message.guild, settings);
    }

    // whitelist add
    else if (input === "whitelistadd") {
      const match = message.guild.findMatchingChannels(args[1]);
      if (!match.length) return message.safeReply(`${args[1]} に一致するチャンネルが見つかりません`);
      response = await whiteListAdd(settings, match[0].id);
    }

    // whitelist remove
    else if (input === "whitelistremove") {
      const match = message.guild.findMatchingChannels(args[1]);
      if (!match.length) return message.safeReply(`${args[1]} に一致するチャンネルが見つかりません`);
      response = await whiteListRemove(settings, match[0].id);
    }

    //
    else response = "無効なコマンドの使用です！";
    await message.safeReply(response);
  },

  async interactionRun(interaction, data) {
    const sub = interaction.options.getSubcommand();
    const settings = data.settings;

    let response;

    if (sub === "status") response = await getStatus(settings, interaction.guild);
    else if (sub === "strikes") response = await setStrikes(settings, interaction.options.getInteger("amount"));
    else if (sub === "action")
      response = await setAction(settings, interaction.guild, interaction.options.getString("action"));
    else if (sub === "debug") response = await setDebug(settings, interaction.options.getString("status"));
    else if (sub === "whitelist") {
      response = getWhitelist(interaction.guild, settings);
    } else if (sub === "whitelistadd") {
      const channelId = interaction.options.getChannel("channel").id;
      response = await whiteListAdd(settings, channelId);
    } else if (sub === "whitelistremove") {
      const channelId = interaction.options.getChannel("channel").id;
      response = await whiteListRemove(settings, channelId);
    }

    await interaction.followUp(response);
  },
};

async function getStatus(settings, guild) {
  const { automod } = settings;

  const logChannel = settings.modlog_channel
    ? guild.channels.cache.get(settings.modlog_channel).toString()
    : "未設定";

  // String Builder
  let desc = stripIndent`
    ❯ **最大行数**: ${automod.max_lines || "なし"}
    ❯ **大量メンション対策**: ${automod.anti_massmention > 0 ? "✓" : "✕"}
    ❯ **添付ファイル対策**: ${automod.anti_attachment ? "✓" : "✕"}
    ❯ **リンク対策**: ${automod.anti_links ? "✓" : "✕"}
    ❯ **招待リンク対策**: ${automod.anti_invites ? "✓" : "✕"}
    ❯ **スパム対策**: ${automod.anti_spam ? "✓" : "✕"}
    ❯ **ゴーストピン対策**: ${automod.anti_ghostping ? "✓" : "✕"}
  `;

  const embed = new EmbedBuilder()
    .setAuthor({ name: "オートモデレーション設定", iconURL: guild.iconURL() })
    .setColor(EMBED_COLORS.BOT_EMBED)
    .setDescription(desc)
    .addFields(
      {
        name: "ホワイトリストに登録されたチャンネル",
        value: automod.wh_channels?.length
          ? automod.wh_channels.map((ch) => `<#${ch}>`).join(", ")
          : "ホワイトリストに登録されたチャンネルはありません",
      },
      {
        name: "ログチャンネル",
        value: logChannel,
      },
      {
        name: "デバッグ",
        value: automod.debug ? "有効" : "無効",
      }
    );

  return { embeds: [embed] };
}

async function setStrikes(settings, strikes) {
  settings.automod.strikes = strikes;
  await settings.save();
  return `ストライクの最大数が ${strikes} に設定されました。`;
}

async function setAction(settings, guild, action) {
  settings.automod.action = action;
  await settings.save();
  return `メンバーが最大ストライクに達したときのアクションが ${action} に設定されました。`;
}

async function setDebug(settings, status) {
  settings.automod.debug = status.toLowerCase() === "on" ? true : false;
  await settings.save();
  return `デバッグモードが ${status.toUpperCase()} に設定されました。`;
}

function getWhitelist(guild, settings) {
  const channels = settings.automod.wh_channels || [];
  if (!channels.length) return "ホワイトリストに登録されたチャンネルはありません";
  const mapped = channels.map((ch) => `<#${ch}>`).join(", ");
  return `ホワイトリストに登録されたチャンネル: ${mapped}`;
}

async function whiteListAdd(settings, channelId) {
  if (settings.automod.wh_channels.includes(channelId))
    return `<#${channelId}> はすでにホワイトリストに登録されています。`;

  settings.automod.wh_channels.push(channelId);
  await settings.save();
  return `<#${channelId}> がホワイトリストに追加されました。`;
}

async function whiteListRemove(settings, channelId) {
  if (!settings.automod.wh_channels.includes(channelId))
    return `<#${channelId}> はホワイトリストに登録されていません。`;

  settings.automod.wh_channels.splice(settings.automod.wh_channels.indexOf(channelId), 1);
  await settings.save();
  return `<#${channelId}> がホワイトリストから削除されました。`;
}
