const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ModalBuilder,
  TextInputBuilder,
  ApplicationCommandOptionType,
  ChannelType,
  ButtonStyle,
  TextInputStyle,
  ComponentType,
} = require("discord.js");
const { EMBED_COLORS } = require("@root/config.js");
const { isTicketChannel, closeTicket, closeAllTickets } = require("@handlers/ticket");

/**
 * @type {import("@structures/Command")}
 */
module.exports = {
  name: "ticket",
  description: "さまざまなチケット関連コマンド",
  category: "TICKET",
  userPermissions: ["ManageGuild"],
  command: {
    enabled: true,
    minArgsCount: 1,
    subcommands: [
      {
        trigger: "setup <#channel>",
        description: "インタラクティブなチケットセットアップを開始します",
      },
      {
        trigger: "log <#channel>",
        description: "チケット用のログチャンネルを設定します",
      },
      {
        trigger: "limit <number>",
        description: "同時にオープンできるチケットの最大数を設定します",
      },
      {
        trigger: "close",
        description: "チケットを閉じます",
      },
      {
        trigger: "closeall",
        description: "すべてのオープンチケットを閉じます",
      },
      {
        trigger: "add <userId|roleId>",
        description: "チケットにユーザーまたはロールを追加します",
      },
      {
        trigger: "remove <userId|roleId>",
        description: "チケットからユーザーまたはロールを削除します",
      },
    ],
  },
  slashCommand: {
    enabled: true,
    options: [
      {
        name: "setup",
        description: "新しいチケットメッセージをセットアップします",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "channel",
            description: "チケット作成メッセージを送信するチャンネル",
            type: ApplicationCommandOptionType.Channel,
            channelTypes: [ChannelType.GuildText],
            required: true,
          },
        ],
      },
      {
        name: "log",
        description: "チケット用のログチャンネルを設定します",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "channel",
            description: "チケットログを送信するチャンネル",
            type: ApplicationCommandOptionType.Channel,
            channelTypes: [ChannelType.GuildText],
            required: true,
          },
        ],
      },
      {
        name: "limit",
        description: "同時にオープンできるチケットの最大数を設定します",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "amount",
            description: "チケットの最大数",
            type: ApplicationCommandOptionType.Integer,
            required: true,
          },
        ],
      },
      {
        name: "close",
        description: "チケットを閉じます [チケットチャンネル内でのみ使用]",
        type: ApplicationCommandOptionType.Subcommand,
      },
      {
        name: "closeall",
        description: "すべてのオープンチケットを閉じます",
        type: ApplicationCommandOptionType.Subcommand,
      },
      {
        name: "add",
        description: "現在のチケットチャンネルにユーザーを追加します [チケットチャンネル内でのみ使用]",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "user_id",
            description: "追加するユーザーのID",
            type: ApplicationCommandOptionType.String,
            required: true,
          },
        ],
      },
      {
        name: "remove",
        description: "チケットチャンネルからユーザーを削除します [チケットチャンネル内でのみ使用]",
        type: ApplicationCommandOptionType.Subcommand,
        options: [
          {
            name: "user",
            description: "削除するユーザー",
            type: ApplicationCommandOptionType.User,
            required: true,
          },
        ],
      },
    ],
  },

  async messageRun(message, args, data) {
    const input = args[0].toLowerCase();
    let response;

    // Setup
    if (input === "setup") {
      if (!message.guild.members.me.permissions.has("ManageChannels")) {
        return message.safeReply("チケットチャンネルを作成するには `Manage Channels` の権限が必要です");
      }
      const targetChannel = message.guild.findMatchingChannels(args[1])[0];
      if (!targetChannel) {
        return message.safeReply("指定したチャンネルが見つかりませんでした");
      }
      return ticketModalSetup(message, targetChannel, data.settings);
    }

    // log ticket
    else if (input === "log") {
      if (args.length < 2) return message.safeReply("チケットログを送信するチャンネルを指定してください");
      const target = message.guild.findMatchingChannels(args[1]);
      if (target.length === 0) return message.safeReply("一致するチャンネルが見つかりませんでした");
      response = await setupLogChannel(target[0], data.settings);
    }

    // Set limit
    else if (input === "limit") {
      if (args.length < 2) return message.safeReply("数値を指定してください");
      const limit = args[1];
      if (isNaN(limit)) return message.safeReply("数値を指定してください");
      response = await setupLimit(limit, data.settings);
    }

    // Close ticket
    else if (input === "close") {
      response = await close(message, message.author);
      if (!response) return;
    }

    // Close all tickets
    else if (input === "closeall") {
      let sent = await message.safeReply("チケットを閉じています ...");
      response = await closeAll(message, message.author);
      return sent.editable ? sent.edit(response) : message.channel.send(response);
    }

    // Add user to ticket
    else if (input === "add") {
      if (args.length < 2) return message.safeReply("チケットに追加するユーザーまたはロールを指定してください");
      let inputId;
      if (message.mentions.users.size > 0) inputId = message.mentions.users.first().id;
      else if (message.mentions.roles.size > 0) inputId = message.mentions.roles.first().id;
      else inputId = args[1];
      response = await addToTicket(message, inputId);
    }

    // Remove user from ticket
    else if (input === "remove") {
      if (args.length < 2) return message.safeReply("チケットから削除するユーザーまたはロールを指定してください");
      let inputId;
      if (message.mentions.users.size > 0) inputId = message.mentions.users.first().id;
      else if (message.mentions.roles.size > 0) inputId = message.mentions.roles.first().id;
      else inputId = args[1];
      response = await removeFromTicket(message, inputId);
    }

    // Invalid input
    else {
      return message.safeReply("コマンドの使い方が間違っています");
    }

    if (response) await message.safeReply(response);
  },

  async interactionRun(interaction, data) {
    const sub = interaction.options.getSubcommand();
    let response;

    // setup
    if (sub === "setup") {
      const channel = interaction.options.getChannel("channel");

      if (!interaction.guild.members.me.permissions.has("ManageChannels")) {
        return interaction.followUp("チケットチャンネルを作成するには `Manage Channels` の権限が必要です");
      }

      await interaction.deleteReply();
      return ticketModalSetup(interaction, channel, data.settings);
    }

    // Log channel
    else if (sub === "log") {
      const channel = interaction.options.getChannel("channel");
      response = await setupLogChannel(channel, data.settings);
    }

    // Limit
    else if (sub === "limit") {
      const limit = interaction.options.getInteger("amount");
      response = await setupLimit(limit, data.settings);
    }

    // Close
    else if (sub === "close") {
      response = await close(interaction, interaction.user);
    }

    // Close all
    else if (sub === "closeall") {
      response = await closeAll(interaction, interaction.user);
    }

    // Add to ticket
    else if (sub === "add") {
      const inputId = interaction.options.getString("user_id");
      response = await addToTicket(interaction, inputId);
    }

    // Remove from ticket
    else if (sub === "remove") {
      const user = interaction.options.getUser("user");
      response = await removeFromTicket(interaction, user.id);
    }

    if (response) await interaction.followUp(response);
  },
};

/**
 * @param {import('discord.js').Message} param0
 * @param {import('discord.js').GuildTextBasedChannel} targetChannel
 * @param {object} settings
 */
async function ticketModalSetup({ guild, channel, member }, targetChannel, settings) {
  const buttonRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("ticket_btnSetup").setLabel("セットアップメッセージ").setStyle(ButtonStyle.Primary)
  );

  const sentMsg = await channel.safeSend({
    content: "以下のボタンをクリックしてチケットメッセージのセットアップを行ってください",
    components: [buttonRow],
  });

  if (!sentMsg) return;

  const btnInteraction = await channel
    .awaitMessageComponent({
      componentType: ComponentType.Button,
      filter: (i) => i.customId === "ticket_btnSetup" && i.member.id === member.id && i.message.id === sentMsg.id,
      time: 20000,
    })
    .catch((ex) => {});

  if (!btnInteraction) return sentMsg.edit({ content: "応答がありませんでした。セットアップをキャンセルします", components: [] });

  // display modal
  await btnInteraction.showModal(
    new ModalBuilder({
      customId: "ticket-modalSetup",
      title: "チケットセットアップ",
      components: [
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId("title")
            .setLabel("埋め込みタイトル")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId("description")
            .setLabel("埋め込み説明")
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(false)
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId("footer")
            .setLabel("埋め込みフッター")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
        ),
      ],
    })
  );

  // receive modal input
  const modal = await btnInteraction
    .awaitModalSubmit({
      time: 1 * 60 * 1000,
      filter: (m) => m.customId === "ticket-modalSetup" && m.member.id === member.id && m.message.id === sentMsg.id,
    })
    .catch((ex) => {});

  if (!modal) return sentMsg.edit({ content: "応答がありませんでした。セットアップをキャンセルします", components: [] });

  await modal.reply("チケットメッセージを設定しています ...");
  const title = modal.fields.getTextInputValue("title");
  const description = modal.fields.getTextInputValue("description");
  const footer = modal.fields.getTextInputValue("footer");

  // send ticket message
  const embed = new EmbedBuilder()
    .setColor(EMBED_COLORS.BOT_EMBED)
    .setAuthor({ name: title || "サポートチケット" })
    .setDescription(description || "以下のボタンを使ってチケットを作成してください")
    .setFooter({ text: footer || "同時にオープンできるチケットは1つだけです！" });

  const tktBtnRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setLabel("チケットを開く").setCustomId("TICKET_CREATE").setStyle(ButtonStyle.Success)
  );

  await targetChannel.send({ embeds: [embed], components: [tktBtnRow] });
  await modal.deleteReply();
  await sentMsg.edit({ content: "完了しました！チケットメッセージが作成されました", components: [] });
}

async function setupLogChannel(target, settings) {
  if (!target.canSendEmbeds()) return `Oops! ${target} に埋め込みを送信する権限がありません`;

  settings.ticket.log_channel = target.id;
  await settings.save();

  return `設定が保存されました！チケットログは ${target.toString()} に送信されます`;
}

async function setupLimit(limit, settings) {
  if (Number.parseInt(limit, 10) < 5) return "チケットの制限は5未満にはできません";

  settings.ticket.limit = limit;
  await settings.save();

  return `設定が保存されました。最大 \`${limit}\` 件のオープンチケットを持つことができます`;
}

async function close({ channel }, author) {
  if (!isTicketChannel(channel)) return "このコマンドはチケットチャンネル内でのみ使用できます";
  const status = await closeTicket(channel, author, "モデレーターによって閉じられました");
  if (status === "MISSING_PERMISSIONS") return "チケットを閉じる権限がありません";
  if (status === "ERROR") return "チケットを閉じる際にエラーが発生しました";
  return null;
}

async function closeAll({ guild }, user) {
  const stats = await closeAllTickets(guild, user);
  return `完了しました！ 成功: \`${stats[0]}\` 失敗: \`${stats[1]}\``;
}

async function addToTicket({ channel }, inputId) {
  if (!isTicketChannel(channel)) return "このコマンドはチケットチャンネル内でのみ使用できます";
  if (!inputId || isNaN(inputId)) return "有効なユーザーIDまたはロールIDを指定してください";

  try {
    await channel.permissionOverwrites.create(inputId, {
      ViewChannel: true,
      SendMessages: true,
    });

    return "完了しました";
  } catch (ex) {
    return "ユーザーまたはロールの追加に失敗しました。正しいIDを指定しましたか？";
  }
}

async function removeFromTicket({ channel }, inputId) {
  if (!isTicketChannel(channel)) return "このコマンドはチケットチャンネル内でのみ使用できます";
  if (!inputId || isNaN(inputId)) return "有効なユーザーIDまたはロールIDを指定してください";

  try {
    channel.permissionOverwrites.create(inputId, {
      ViewChannel: false,
      SendMessages: false,
    });
    return "完了しました";
  } catch (ex) {
    return "ユーザーまたはロールの削除に失敗しました。正しいIDを指定しましたか？";
  }
}
